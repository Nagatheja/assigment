package edubridge;

import java.util.Scanner;

public class Leapyear {
	 static int year;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner reader = new Scanner(System.in);
		System.out.println("enter year");
		year=reader.nextInt();
		if( (year%400==0 || year%100!=0) &&(year%4==0))
			System.out.println("It is a leap year");
		else
			System.out.println("It is not a leap year");
	}

}
