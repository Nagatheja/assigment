package edubridge;
import java.util.Scanner;
public class Triangle {
	public static void main(String[] args) {
		int angle1,angle2,angle3;
		Scanner reader = new Scanner(System.in);
		System.out.println("angle1");
		angle1=reader.nextInt();
		System.out.println("angle1");
		angle2=reader.nextInt();
		System.out.println("angle1");
		angle3=reader.nextInt();
		if (angle1+angle2+angle3==180)
			System.out.println("Triangle is valid");
		else
			System.out.println("Triangle is not valid");
		
	}
}
