package edubridge;

import java.util.Scanner;

public class Totalexp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int totalexp, qty, price, discount;
Scanner reader = new Scanner(System.in);
System.out.println("enter quntity");
qty=reader.nextInt();
System.out.println("enter price");
price=reader.nextInt();
totalexp=qty*price;
if(totalexp>5000)
{
	discount=(int) (totalexp*0.1);
	totalexp=totalexp-discount;
}
System.out.println("Total Expense is  Rs."+totalexp);


	}

}
