package edubridge;

import java.util.Scanner;

public class Youngest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ram_age,sulabh_age,ajay_age;
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter Ram age ");
		ram_age=reader.nextInt();
		System.out.println("Enter Sulabh age ");
		sulabh_age=reader.nextInt();
		System.out.println("Enter ajay age ");
		ajay_age=reader.nextInt();
		if (ram_age<sulabh_age && ram_age<ajay_age)
			System.out.println("Ram is youngest");
		else if(sulabh_age<ram_age && sulabh_age<ajay_age)
			System.out.println("Sulabh is youngest");
		else
			System.out.println("Ajay is youngest");

		
	}

}
