package edubridge;

import java.util.Scanner;

public class Evevodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner reader=new Scanner(System.in);
		System.out.println("enter a number");
		n=reader.nextInt();
		if(n%2==0)
			System.out.println("The number is even");
		else
			System.out.println("The number is odd");
		
	}

}
