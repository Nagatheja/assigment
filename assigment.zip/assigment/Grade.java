package edubridge;

import java.util.Scanner;

public class Grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sub1,sub2,sub3,sub4,sub5,percentage;
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter marks of five subjects :");
		sub1=reader.nextInt();
		sub2=reader.nextInt();
		sub3=reader.nextInt();
		sub4=reader.nextInt();
		sub5=reader.nextInt();
		percentage=(sub1+sub2+sub3+sub4+sub5)/5;
		if(percentage>=60)
			System.out.println("Ist division");
		else if(percentage>=50)
			System.out.println("IInd division");
		else if(percentage>=40)
			System.out.println("IIIrd division");
		else
			System.out.println("Fail") ;
	}

}
