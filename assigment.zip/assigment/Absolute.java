package edubridge;

import java.util.Scanner;

public class Absolute {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		Scanner reader=new Scanner(System.in);
		System.out.println("enter any number: ");
		a=reader.nextInt();
		if(a>0)
			System.out.println("The absolute value of number is:"+a);
		else
			System.out.println("The absolute value of number is:"+-(a));


}
}
