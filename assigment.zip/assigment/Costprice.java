package edubridge;

import java.util.Scanner;

public class Costprice {
	public static void main(String[] args) {
		int cp,sp,result;
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter cost price of item ");
		cp=reader.nextInt();
		System.out.println("Enter selling price of item ");
		sp=reader.nextInt();
		result=sp-cp;
		if(result>0)
			System.out.println("Profit: "+result);
		else
			if(result<0)
				System.out.println("Loss: "+result);
			else
				System.out.println("No profit no loss");

	}
}
