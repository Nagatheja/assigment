package edubridge;

import java.util.Scanner;

public class Grosssalary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double basic_salary, gross_salary, HRA, DA;
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter basic salary of Employee : ");
		basic_salary=reader.nextDouble();
		if (basic_salary<1500)
		{
			HRA=0.1*basic_salary;
			DA=0.9*basic_salary;
		}
		else
		{	
			HRA=500;
			DA=0.98*basic_salary;
		}

		gross_salary=basic_salary+HRA+DA;
		System.out.println("Gross salary is : "+gross_salary);
		
	}

}
